import math

ENABLE_EXPRIMENTAL_FEATURES = True

class Vector2D:
    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y
    
    def __eq__(self, other):
        return self.x == other.x and self.y == other.y

    def __add__(self, other):
        return type(self)(self.x + other.x, self.y + other.y)

    def __sub__(self, other):
        return type(self)(self.x - other.x, self.y - other.y)

    def __mul__(self, other):
        if isinstance(other, Vector2D):
            return self.x * other.x + self.y * other.y
        elif isinstance(other, (int, float)):
            return type(self)(self.x * other, self.y * other)
        else:
            raise TypeError("Unsupported operand type(s) for *: '{}' and '{}'".format(type(self).__name__, type(other).__name__))
    
    def __rmul__(self, other):
        return self * other
        # 注意：在MicroPython中，不会考虑调用__rmul__，而是直接在对方对象上调用__mul__，因此需要注意乘法顺序
    
    def cross(self, other):
        if isinstance(other, Vector2D):
            return self.x * other.y - self.y * other.x
        else:
            raise TypeError("Unsupported operand type(s) for cross: '{}' and '{}'".format(type(self).__name__, type(other).__name__))

    def __truediv__(self, other):
        if isinstance(other, (int, float)):
            return type(self)(self.x / other, self.y / other)
        else:
            raise TypeError("Unsupported operand type(s) for /: '{}' and '{}'".format(type(self).__name__, type(other).__name__))
    
    def normalize(self):
        return self / abs(self)
    
    def __neg__(self):
        return type(self)(-self.x, -self.y)
    
    def __abs__(self):
        return math.sqrt(self.x ** 2 + self.y ** 2)
    
    def __repr__(self):
        return "Vector2D({}, {})".format(self.x, self.y)
    
    def rotate90(self):
        return type(self)(-self.y, self.x)

class Pos2D(Vector2D):
    pass

class CollisionPoint:
    """碰撞点。仅内部使用"""
    def __init__(self, 
                 pos: Pos2D, 
                 normal: Vector2D
    ):
        """
        pos: 碰撞点位置  
        normal: 碰撞点单位法向量
        """
        self.pos = pos
        self.normal = normal


class PhysicalObject:
    """通用物理对象"""
    def __init__(self, 
                 pos: Pos2D, 
                 mass: float,
                 fixed: bool = False
    ):
        self.name = repr(self)
        self.pos = pos
        self.mass = mass
        self.fixed = fixed
        self.extra_force = Vector2D(0, 0)
        self.extra_acceleration = Vector2D(0, 0)
        self.velocity = Vector2D(0, 0)
        self.collision_handler = None
        """碰撞处理函数，参数: 碰撞点"""
        self.collision_energy_loss = 0.0
        """碰撞能量损失，0-1之间，0表示无能量损失，1表示完全能量损失"""
    def collision(self, other):
        raise NotImplementedError

class Circle(PhysicalObject):
    def __init__(self, 
                 pos: Pos2D, 
                 radius: float,
                 mass: float, 
                 fixed: bool = False
    ):
        super().__init__(pos, mass, fixed)
        self.radius = radius
    def collision(self, other: PhysicalObject):
        if isinstance(other, Circle):
            # 碰撞位置：两圆心的加权中点
            pos = self.pos + (other.pos - self.pos) * (self.radius / (self.radius + other.radius))
            try:
                dis = abs(self.pos - other.pos)
            except OverflowError:
                print("OverflowError: self.pos = {}, other.pos = {}, self.pos-other.pos = {}".format(self.pos, other.pos, (self.pos - other.pos)))
                raise
            # 若两圆心距离小于两圆半径之和，则碰撞。为优化逻辑，这里检查是否不碰撞
            if dis >= (self.radius + other.radius):
                return None
            # 两圆心单位法向量，任意方向
            normal = (self.pos - other.pos).normalize() # 注意：该向量指向self_pos
            # 优化：
            # 如果两圆均不固定，则按质量比，按碰撞法向移动两圆心，使两圆恰好接触
            # 如果一圆固定，则移动另一圆心，使两圆恰好接触
            # 穿透深度
            penetration = self.radius + other.radius - dis

            # 按质量分配移动量
            if not self.fixed and not other.fixed and ENABLE_EXPRIMENTAL_FEATURES: # 实验性
                # 仅在阈值范围内进行碰撞处理
                # 方案1: 质量大的移动少
                """
                total_mass = self.mass + other.mass
                self.pos += normal * (penetration * other.mass / total_mass)
                other.pos -= normal * (penetration * self.mass / total_mass)
                """
                # 方案2: 按半径平均分配移动量
                self.pos += normal * (penetration * (other.radius / (self.radius + other.radius)))
                other.pos -= normal * (penetration * (self.radius / (self.radius + other.radius)))
            elif self.fixed:
                other.pos = pos - normal * other.radius * 2
            elif other.fixed:
                self.pos = pos + normal * self.radius * 2
            return CollisionPoint(pos, normal)
        else:
            return other.collision(self)

class Line(PhysicalObject):
    def __init__(self, 
                 pos: Pos2D, 
                 direction: Vector2D,
                 mass: float, 
                 fixed: bool = False
    ):
        super().__init__(pos, mass, fixed)
        self.direction = direction.normalize()
        if self.direction == Vector2D(0, 0):
            raise ValueError("Direction vector cannot be zero")
    def collision(self, other: PhysicalObject):
        if isinstance(other, Line):
            raise NotImplementedError
        elif isinstance(other, Circle):
            # 圆心到直线上一点p的向量
            c = other.pos
            p = self.pos
            d = self.direction

            # 投影参数t
            t = d * (c - p)
            # 垂足坐标
            foot = p + d * t

            # 从垂足指向圆心的向量
            vec = c - foot
            dist = abs(vec)

            if dist >= other.radius:
                return None

            # 碰撞点：圆与直线的接触点（在圆的边界上，沿法向从圆心后退半径距离）
            # 注意：直线无限长，碰撞点应该是圆心沿法向向直线移动半径距离的点
            if dist == 0:
                # 圆心正好在直线上，法向可以取垂直方向
                normal = d.rotate90()  # 垂直向量
            else:
                normal = vec.normalize()

            # 优化:如果线是固定的，将圆的坐标设置为恰好让线接触圆的边界而不进入圆内
            if self.fixed:
                other.pos = foot + normal * other.radius

            return CollisionPoint(foot, normal)
        else:
            return other.collision(self)
    def get_xy_intpos(self):
        """计算自身与x,y轴的交点  
        返回(x, y)  
            表示交点(x, 0)(0, y)
        若直线水平, x为None
        若直线垂直, y为None
        """
        if self.direction.y == 0:
            x = None
        else:
            x = self.pos.x - self.direction.x / self.direction.y * self.pos.y
        if self.direction.x == 0:
            y = None
        else:
            y = self.pos.y - self.direction.y / self.direction.x * self.pos.x
        return (x, y)

class Physics2D:
    def __init__(self):
        self.objects: list[PhysicalObject] = []
        self.global_force = Vector2D(0, 0)
        self.global_acceleration = Vector2D(0, 0)
        self.collision_handler = None
        """collision_handler参数列表：obj1, obj2, collision_point"""
        self.update_callback = None
        """update_callback参数列表：dt"""
    def update_move(self, dt: float):
        """仅更新移动，不考虑碰撞"""
        for obj in self.objects:
            if obj.fixed:
                continue
            obj_acceleration = (self.global_force + obj.extra_force) / obj.mass + (obj.extra_acceleration + self.global_acceleration)
            obj.velocity += obj_acceleration * dt
            obj.pos += obj.velocity * dt
    def update_collision(self):
        """更新碰撞"""
        # 碰撞检查与处理函数
        def handle_collision(obj1: PhysicalObject, obj2: PhysicalObject):
            # 检查碰撞
            collision_point = obj1.collision(obj2)
            if collision_point is None:
                return
            # 调用handler
            if self.collision_handler is not None:
                self.collision_handler(obj1, obj2, collision_point)
            if obj1.collision_handler is not None:
                obj1.collision_handler(collision_point)
            if obj2.collision_handler is not None:
                obj2.collision_handler(collision_point)
            
            # 计算各自的动能保留率
            obj1_p = 1.0 - obj1.collision_energy_loss
            obj2_p = 1.0 - obj2.collision_energy_loss
            # print(f"{obj1.name}与{obj2.name}碰撞")
            # 处理碰撞
            # 根据动量守恒和动能守恒计算碰撞后的速度

            # 根据法向向量计算切向向量
            tangent = collision_point.normal.rotate90()
            
            # 两物体的速度分解到法向和切向
            v1n = obj1.velocity * collision_point.normal 
            v1t = obj1.velocity * tangent
            v2n = obj2.velocity * collision_point.normal
            v2t = obj2.velocity * tangent

            # 损失动能
            v1n *= obj1_p
            v2n *= obj2_p

            # 根据fixed属性判断是否需要更新速度
            if obj1.fixed:
                # obj2的法向反弹
                v2n = -v2n
                # 损失对面的动能
                v1n *= obj2_p
            elif obj2.fixed:
                # obj1的法向反弹
                v1n = -v1n
                # 损失对面的动能
                v2n *= obj1_p
            else: # 计算
                # 法向上两物体碰撞后的速度。为了加速计算，这里缓存部分变量。
                m1_p_m2 = obj1.mass + obj2.mass
                v1n, v2n = (
                    (v1n * (obj1.mass - obj2.mass) + 2 * obj2.mass * v2n) / m1_p_m2, 
                    (v2n * (obj2.mass - obj1.mass) + 2 * obj1.mass * v1n) / m1_p_m2
                )
            

            # 合并切向和法向速度
            obj1.velocity = collision_point.normal * v1n + tangent * v1t # type: ignore
            obj2.velocity = collision_point.normal * v2n + tangent * v2t # type: ignore

        # 两两检查碰撞
        for i in range(len(self.objects)):
            for j in range(i + 1, len(self.objects)):
                obj1 = self.objects[i]
                obj2 = self.objects[j]
                # 是否均是固定物体
                if obj1.fixed and obj2.fixed:
                    continue
                handle_collision(obj1, obj2)
    def update(self, dt: float):
        """更新。"""
        if self.update_callback is not None:
            self.update_callback(dt)
        self.update_move(dt)
        self.update_collision()

