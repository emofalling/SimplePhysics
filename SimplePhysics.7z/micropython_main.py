from physics2d import *
from devlib import *

import utime # type: ignore

SCR_WIDTH = 128
SCR_HEIGHT = 64

phys = Physics2D()
# 全局重力
phys.global_acceleration = Vector2D(0, -9.81)
# 地面
floor = Line(
    Pos2D(0, 1),
    Vector2D(1, 0),
    0,
    True
)
floor.name = "floor"
# 坡
slope = Line(
    Pos2D(10-math.sqrt(2)/2, 10-math.sqrt(2)/2),
    Vector2D(1, -1),
    0,
    True
)
slope.name = "slope"
# 坡2
slope2 = Line(
    Pos2D(30, 1),
    Vector2D(1, 1),
    0,
    True
)
slope2.name = "slope2"
# 球
ball = Circle(
    Pos2D(10, 10),
    1,
    1,
)
ball.name = "ball"
# 0.5的动能损失
ball.collision_energy_loss = 0.0

# 击打的球
hit_ball = Circle(
    Pos2D(29, 3),
    1,
    1,
)
hit_ball.name = "hit_ball"


phys.objects.append(ball)
phys.objects.append(floor)
phys.objects.append(slope)
phys.objects.append(slope2)
phys.objects.append(hit_ball)# 当前存在问题


scale = 3

def __normal_start_end(start, end):
    # 将start和end标准化，使start end的所有坐标非负，但效果不变
    x_int, y_int = end[0], start[1]
    width = SCR_WIDTH
    height = SCR_HEIGHT
    k = -y_int / x_int
    b = y_int

    # 找出与画布边界在正区域的交点
    new_points = []

    # 检查与画布底边(y=height)的交点
    x_at_height = (height - b) / k
    if 0 <= x_at_height <= width:
        new_points.append((x_at_height, height))

    # 检查与画布右边(x=width)的交点
    y_at_width = k * width + b
    if 0 <= y_at_width <= height:
        new_points.append((width, y_at_width))

    # 检查与画布上边(y=0)的交点
    x_at_top = -b / k
    if 0 <= x_at_top <= width:
        new_points.append((x_at_top, 0))

    # 检查与画布左边(x=0)的交点
    y_at_left = b
    if 0 <= y_at_left <= height:
        new_points.append((0, y_at_left))
    
    assert len(new_points) >= 2, "没有足够的交点以确定直线，当前只有如下交点：{}".format(new_points)

    # 取两点
    return new_points[0], new_points[1]

def drawPhysics():
    oled.fill(0)
    for obj in phys.objects:
        if isinstance(obj, Circle):
            oled.circle(round(obj.pos.x*scale), SCR_HEIGHT-round(obj.pos.y*scale), round(obj.radius*scale), 1)
        elif isinstance(obj, Line):
            x, y = obj.get_xy_intpos()
            if x is None:
                start = (0, y)
                end = (SCR_WIDTH, y)
            elif y is None:
                start = (x, 0)
                end = (x, SCR_HEIGHT)
            else:
                start = (0, y)
                end = (x, 0)
                
                start, end = __normal_start_end(start, end)
            oled.line(round(start[0]*scale), SCR_HEIGHT-round(start[1]*scale), # type: ignore
                      round(end[0]*scale), SCR_HEIGHT-round(end[1]*scale), 1) # type: ignore
    oled.show()

td = 0.0

while True:
    ts = utime.ticks_us()
    phys.update(td / 1000000)
    drawPhysics()
    td = utime.ticks_diff(utime.ticks_us(), ts)